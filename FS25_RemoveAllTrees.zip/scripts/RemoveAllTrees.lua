-- RemoveAllTrees.lua
-- One-shot: after the mission finishes loading, delete every standing tree.
-- Runs server-side only. Tree detection uses the same test as the game's own
-- TreePlantManager:onTreeCutCommandOverlapCallback (cutTrees console command):
--   MESH_SPLIT_SHAPE + splitType ~= 0 + STATIC rigid body.
-- Deletion mirrors StumpCutter:crushSplitShape: delete(shape) + dirty collision/AI maps.

RemoveAllTrees = {}
RemoveAllTrees.done = false

local function collectTrees(node, list)
    local count = getNumOfChildren(node)
    for i = 0, count - 1 do
        local child = getChildAt(node, i)
        if getHasClassId(child, ClassIds.MESH_SPLIT_SHAPE) then
            -- Split shape children are branches/attachments; never descend into them.
            if getSplitType(child) ~= 0 and getRigidBodyType(child) == RigidBodyType.STATIC then
                table.insert(list, child)
            end
        else
            collectTrees(child, list)
        end
    end
end

function RemoveAllTrees.run()
    if RemoveAllTrees.done then return end
    RemoveAllTrees.done = true

    if g_currentMission == nil or not g_currentMission:getIsServer() then
        print("[RemoveAllTrees] Not server, skipping.")
        return
    end

    local trees = {}
    collectTrees(getRootNode(), trees)
    print(string.format("[RemoveAllTrees] Found %d standing trees, deleting...", #trees))

    local deleted = 0
    for _, shape in ipairs(trees) do
        if entityExists(shape) then
            g_treePlantManager:removingSplitShape(shape)
            delete(shape)
            deleted = deleted + 1
        end
    end

    -- Purge TreePlantManager's planted-tree lists of trees whose shapes are now gone.
    g_treePlantManager:cleanupDeletedTrees()

    -- Rebuild collision map and AI navigation for the whole terrain in one go.
    local size = g_currentMission.terrainSize or 4096
    local half = size / 2
    g_densityMapHeightManager:setCollisionMapAreaDirty(-half, -half, half, half, true)
    if g_currentMission.aiSystem ~= nil then
        g_currentMission.aiSystem:setAreaDirty(-half, half, -half, half)
    end

    print(string.format("[RemoveAllTrees] Deleted %d trees. SAVE THE GAME, then remove this mod.", deleted))
end

-- Confirmed from log: FSBaseMission.onFinishedLoading fires via BaseMission:finishLoadingTask
-- after map, split shapes, and vehicles are all loaded.
FSBaseMission.onFinishedLoading = Utils.appendedFunction(FSBaseMission.onFinishedLoading, function(mission)
    RemoveAllTrees.run()
end)
